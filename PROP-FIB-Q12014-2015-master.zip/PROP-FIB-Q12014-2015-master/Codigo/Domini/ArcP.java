package Domini;

/**
 * @autor Laura
 * @dataCreación 6/11/1014
 * @dataÚltimaModificación 7/11/2014
 */

public class ArcP {
    public int first;
    public int second;
    
    //Constructoras
    
    /**
     * @pre cierto
     * @post crea una instrancia de la clase ArcP con first = f y second = s
     */
    public ArcP(int f, int s){
        this.first = f;
        this.second = s;
    }
}
